﻿public enum MediaType
{
    None,
    Image,
    Video
}