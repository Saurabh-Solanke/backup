﻿namespace Online_Knowledge_Test_Backend_V2.Services.Interfaces
{
    public interface IUserService
    {
    }
}
